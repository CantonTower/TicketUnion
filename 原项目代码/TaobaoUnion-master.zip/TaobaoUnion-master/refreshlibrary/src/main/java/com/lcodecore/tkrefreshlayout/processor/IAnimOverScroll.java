package com.lcodecore.tkrefreshlayout.processor;

/**
 * Created by lcodecore on 2017/3/3.
 */

public interface IAnimOverScroll {
    void animOverScrollTop(float vy, int computeTimes);
    void animOverScrollBottom(float vy, int computeTimes);
}

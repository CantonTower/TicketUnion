package com.sunofbeaches.taobaounion.ui.activity;

public interface IMainActivity {

    void switch2Search();
}
